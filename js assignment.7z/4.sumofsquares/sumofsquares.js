var inputarray = document.getElementById('input');
var show = document.getElementById('show');
var addelement = document.getElementById('add');
var array = [];
var output=0;
var temp=0;

function add() {
    if (inputarray.value == '') {
        show.innerText = "Invalid Input"
    }
    else {
        array.push(parseInt(inputarray.value));
    }
}
function clear() {
    inputarray.value = '';
}
addelement.addEventListener('click', add);
addelement.addEventListener('click', clear);

function sumSquared() {
    for (i = 0; i < array.length; i++) {
        temp = array[i] * array[i];
        output = output + temp;
        temp = 0;
    }
    show.innerText = `The sum of the elements of the array squared is ${output}`;
}
