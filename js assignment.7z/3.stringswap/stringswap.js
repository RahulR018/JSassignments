var inputarray = document.getElementById('input');
var show = document.getElementById('show');
var addelement = document.getElementById('add');
var array = [];
var output = [];
var output1 = [];
var output2 = [];

function add() {
    if (inputarray.value == '') {
        show.innerText = "Invalid Input"
    }
    else {
        array.push(inputarray.value);
    }
}
function clear() {
    inputarray.value = '';
}
addelement.addEventListener('click', add);
addelement.addEventListener('click', clear);

function swap() {
    for (i = 0; i < array.length; i++) {
        for (j = 0; j < array[i].length; j++) {
            if (array[i][j] != array[i][j].toUpperCase()) {
                output1.push(array[i][j].toUpperCase());
            } else if (array[i][j] != array[i][j].toLowerCase()) {
                output1.push(array[i][j].toLowerCase());
            }
        }
        output[i] = output1.join('');
        output1 = [];
    }
    show.innerText = output;
}