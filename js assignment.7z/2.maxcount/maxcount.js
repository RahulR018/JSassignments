var inputarray = document.getElementById('input');
var show = document.getElementById('show');
var addelement = document.getElementById('add');
var array = [];
var mf = 1;
var m = 0;
var item;
function add() {
    if (inputarray.value == '') {
        show.innerText = 'Invalid input';
    }
    else {
        array.push(inputarray.value);
    }
}
function clear() {
    inputarray.value = '';
}
addelement.addEventListener('click', add);
addelement.addEventListener('click', clear);

function find() {
    for (i = 0; i < array.length; i++) {
        for (j = i; j < array.length; j++) {
            if (array[i] == array[j]) {
                m++;
            }
            if (mf < m) {
                mf = m;
                item = array[i];
            }
        }
        m = 0;
    }
    show.innerText = item + " is repeated " + mf + "times";
}

