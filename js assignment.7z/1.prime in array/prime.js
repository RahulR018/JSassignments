var inputarray = document.getElementById('input');
var flag = true;
var data = [];
function add() {
    if (inputarray.value == '') {
        document.getElementById('show').innerText = "Enter a number";
    } else {
        document.getElementById('show').innerText = "";
        data.push(parseInt(inputarray.value));
    }
}

function confirm() {
    if (data[0] == 1 || data[0] == 0 || data[0] < 0) {
        document.getElementById('show').innerText = "FIRST NUMBER SHOULD NOT BE ONE,ZERO OR NEGATIVE";
    }
    else if (data[0] == 2) {
        document.getElementById('show').innerText = '2 IS THE FIRST PRIME NUMBER';
    }
    else if (data[0] > 2) {
        for (var i = 2; i < data[0]; i++) {
            if ((data[0] % i) == 0) {
                flag = false;
                break;
            }
        }
        if (flag == false) {
            document.getElementById('show').innerText = 'THE FIRST NUMBER IN THE ARRAY IS NOT PRIME';
        } else if (flag == true) {
            document.getElementById('show').innerText = 'THE FIRST NUMBER IN THE ARRAY IS PRIME';
        }
    }
}