var inputarray = document.getElementById('input');
var show = document.getElementById('show');
var addelement = document.getElementById('add');
var resetall = document.getElementById('reset');
var array = [];
var el;
var newone;

function add() {
    if (inputarray.value == '') {
        show.innerText = "INVALID INPUT";
    }
    else if (array.length < 16) {
        array.push(parseInt(inputarray.value));
    }
    else {
        show.innerText = "Index of array out of range. Hit Reset and start again.";
    }
}
function clear() {
    inputarray.value = '';
    show.classList.remove("animation")

}
addelement.addEventListener('click', add);
addelement.addEventListener('click', clear);
addelement.addEventListener('click', oddoreven);
resetall.addEventListener('click', reset);


function oddoreven() {
    for (i = 0; i < array.length; i++) {
        if (array[i] == 0 || (array[i] % 2) == 0) {
            show.innerText = `${array[i]} IS EVEN`;
        } else {
            show.innerText = `${array[i]} IS ODD`;
        }
    }
}

function reset() {
    array = [];
    show.innerText = '';
}
